<?php
/**
 * Localized data
 *
 * @copyright Copyright (C) 2010-2024 Combodo SAS
 * @license    https://opensource.org/licenses/AGPL-3.0
 * 
 */
/**
 * @author Benjamin Planque <benjamin.planque@combodo.com>
 *
 */
Dict::Add('DA DA', 'Danish', 'Dansk', [
	'Brick:Portal:ClosedRequests:Title' => 'Closed requests~~',
	'Brick:Portal:ListAllRequests:Tab' => 'On-going and closed~~',
	'Brick:Portal:ListAllRequests:Title' => 'All requests~~',
	'Brick:Portal:ListAllRequests:Title+' => '<p>View all requests regardless of their status.</p>~~',
	'Brick:Portal:NewRequest:Title' => 'New request~~',
	'Brick:Portal:NewRequest:Title+' => '<p>Need help?</p><p>Pick from the services catalog and submit your request to our support teams.</p>~~',
	'Brick:Portal:OngoingRequests:Tab:OnGoing' => 'Open~~',
	'Brick:Portal:OngoingRequests:Tab:Resolved' => 'Resolved~~',
	'Brick:Portal:OngoingRequests:Title' => 'Ongoing requests~~',
	'Brick:Portal:OngoingRequests:Title+' => '<p>Follow up with your ongoing requests.</p><p>Check the progress, add comments, attach documents, acknowledge the solution.</p>~~',
	'Brick:Portal:SearchInAllRequests:Title' => 'Search in all requests~~',
	'Brick:Portal:SearchInAllRequests:Title+' => '<p>Regardless of their status.</p>~~',
	'Brick:Portal:UserProfile:Title' => 'My profile~~',
	'Page:DefaultTitle' => '%1$s - User portal~~',
	'portal:itop-portal' => 'Standard portal~~',
]);
