# Extension OAuth 2.0 client

## GMail

If the account is in test, after 7 days the tokens are no longer valid, you have to renew the tokens manually.
